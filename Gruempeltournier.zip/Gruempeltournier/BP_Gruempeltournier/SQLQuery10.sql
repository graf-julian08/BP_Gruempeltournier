﻿USE Gruempeli;

SELECT * FROM Spieler;

SELECT * FROM Team;

SELECT * FROM Spielplan;