﻿ALTER TABLE dbo.Team
ADD CONSTRAINT UQ_Team_Teamname UNIQUE (Teamname);
