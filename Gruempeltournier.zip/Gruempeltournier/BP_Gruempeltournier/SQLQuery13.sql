﻿USE Gruempeli;

DELETE FROM Spielplan;