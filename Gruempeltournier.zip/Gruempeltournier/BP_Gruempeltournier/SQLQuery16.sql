﻿SELECT * from Spieler;

SELECT * FROM Team;

SELECT * FROM Spielplan;

SELECT * FROM TeamSpieler;