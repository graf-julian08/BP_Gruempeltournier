﻿ALTER TABLE dbo.Spielplan
ALTER COLUMN Spielstart datetime2(0) NOT NULL;
