﻿USE Gruempeli;

SELECT * FROM Team;