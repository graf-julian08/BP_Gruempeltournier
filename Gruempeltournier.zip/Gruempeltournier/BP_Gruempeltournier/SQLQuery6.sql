﻿USE Gruempeli;

SELECT * FROM Spielplan;