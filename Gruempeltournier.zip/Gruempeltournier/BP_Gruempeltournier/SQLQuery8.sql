﻿USE Gruempeli;

SELECT * FROM Spielplan;

SELECT * FROM Team;

SELECT * FROM Spieler;
