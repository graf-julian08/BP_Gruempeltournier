﻿SELECT * FROM Spieler;
